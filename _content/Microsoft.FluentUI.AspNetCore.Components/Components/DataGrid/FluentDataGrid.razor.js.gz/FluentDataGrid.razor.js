let grids = [];

const focusableSelectors = "input, select, textarea, button, object, a[href], area[href], [tabindex]";

function getFocusableElements(container) {
    const queriedElements = Array.from(container.querySelectorAll("*")).filter(el => {
        return el.matches(focusableSelectors) || el.tagName.toLowerCase().startsWith("fluent-");
    });

    const focusableElements = [];
    queriedElements.forEach(el => {
        if (el.tagName.toLowerCase().startsWith("fluent-") && el.tabIndex === -1 && !!el.shadowRoot) {
            // The host itself is not focusable, so collect what it renders in its shadow root instead.
            // Those elements are not always direct children of the shadow root (a text field renders
            // its input inside a wrapper), so the whole shadow tree has to be queried.
            el.shadowRoot.querySelectorAll(focusableSelectors).forEach(child => {
                if (child.tabIndex !== -1 && child.checkVisibility()) {
                    focusableElements.push(child);
                }
            });
        } else {
            focusableElements.push(el);
        }
    });

    return focusableElements.filter(el => !!el && el.tabIndex !== -1 && el.checkVisibility());
}

function indexOfFocusableElement(focusableElements, element) {
    // Fluent web components delegate focus into their shadow root, so the event origin is often a
    // shadow descendant of the element that was collected. Walk up the composed tree to find it.
    let node = element;
    while (node) {
        const index = focusableElements.indexOf(node);
        if (index !== -1) {
            return index;
        }

        node = node.parentNode ?? node.host;
    }

    return -1;
}

function findAdjacentFocusableElement(currentElement, reverse = false) {
    const focusableElements = getFocusableElements(document.body);
    const currentIndex = indexOfFocusableElement(focusableElements, currentElement);
    if (currentIndex === -1) {
        return null;
    }

    return focusableElements[currentIndex + (reverse ? -1 : 1)] ?? null;
}

function closeColumnResizeAndFocus(gridElement, columnResizeElement, focusTarget) {
    gridElement.dispatchEvent(new CustomEvent('closecolumnresize', { bubbles: true }));

    const columnHeaderButton = columnResizeElement.closest('.column-header')?.querySelector('.col-sort-button');
    (focusTarget ?? columnHeaderButton ?? gridElement).focus();
}

export function init(gridElement, autoFocus) {
    if (gridElement === undefined || gridElement === null) {
        return;
    };

    const controller = new AbortController();
    const { signal } = controller;

    enableColumnResizing(gridElement, true, signal);

    let start = gridElement.querySelector('td:first-child');

    if (autoFocus) {
        start.focus();
    }

    const bodyClickHandler = event => {
        const columnOptionsElement = gridElement?.querySelector('.col-options');
        if (columnOptionsElement && event.composedPath().indexOf(columnOptionsElement) < 0) {
            gridElement.dispatchEvent(new CustomEvent('closecolumnoptions', { bubbles: true }));
        }
        const columnResizeElement = gridElement?.querySelector('.col-resize');
        if (columnResizeElement && event.composedPath().indexOf(columnResizeElement) < 0) {
            gridElement.dispatchEvent(new CustomEvent('closecolumnresize', { bubbles: true }));
        }
    };
    const bodyKeyDownHandler = event => {
        if (event.key === "Escape") {
            const columnOptionsElement = gridElement?.querySelector('.col-options');
            if (columnOptionsElement && columnOptionsElement.contains(event.target)) {
                gridElement.dispatchEvent(new CustomEvent('closecolumnoptions', { bubbles: true }));
                gridElement.focus();
            }
            const columnResizeElement = gridElement?.querySelector('.col-resize');
            if (columnResizeElement) {
                gridElement.dispatchEvent(new CustomEvent('closecolumnresize', { bubbles: true }));
                gridElement.focus();
            }
        }
    };
    const keyboardNavigation = (sibling) => {
        if (sibling !== null) {
            start.focus();
            sibling.focus();
            start = sibling;
        }
    }
    const keyDownHandler = event => {
        const columnOptionsElement = gridElement?.querySelector('.col-options');
        if (columnOptionsElement && columnOptionsElement.contains(event.target)) {
            if (event.key === "ArrowRight" || event.key === "ArrowLeft" || event.key === "ArrowDown" || event.key === "ArrowUp") {
                event.stopPropagation();
                return;
            }
        }

        const columnResizeElement = gridElement?.querySelector('.col-resize');
        if (columnResizeElement && columnResizeElement.contains(event.target)) {
            if (event.key === "ArrowRight" || event.key === "ArrowLeft" || event.key === "ArrowDown" || event.key === "ArrowUp") {
                event.stopPropagation();
                return;
            }

            if (event.key === "Tab") {
                const activeElement = event.composedPath()[0];
                const resizeFocusables = getFocusableElements(columnResizeElement);
                const activeIndex = indexOfFocusableElement(resizeFocusables, activeElement);
                const isFirstElement = activeIndex === 0;
                const isLastElement = activeIndex !== -1 && activeIndex === resizeFocusables.length - 1;

                if ((event.shiftKey && isFirstElement) || (!event.shiftKey && isLastElement)) {
                    const focusTarget = findAdjacentFocusableElement(activeElement, event.shiftKey);
                    event.preventDefault();
                    event.stopPropagation();
                    closeColumnResizeAndFocus(gridElement, columnResizeElement, focusTarget);
                }

                return;
            }
        }

        if (document.activeElement.tagName.toLowerCase() != 'table' && document.activeElement.tagName.toLowerCase() != 'td' && document.activeElement.tagName.toLowerCase() != 'th') {
            return;
        }

        // check if start is a child of gridElement
        if (start !== null && (gridElement.contains(start) || gridElement === start) && document.activeElement === start && document.activeElement.tagName.toLowerCase() !== 'fluent-text-field' && document.activeElement.tagName.toLowerCase() !== 'fluent-menu-item') {
            const idx = start.cellIndex;
            const isRTL = getComputedStyle(gridElement).direction === 'rtl';

            if (event.key === "ArrowUp") {
                // up arrow
                const previousRow = start.parentElement.previousElementSibling;
                if (previousRow !== null) {
                    event.preventDefault();
                    const previousSibling = previousRow.cells[idx];
                    keyboardNavigation(previousSibling);
                }
            } else if (event.key === "ArrowDown") {
                // down arrow
                const nextRow = start.parentElement.nextElementSibling;
                if (nextRow !== null) {
                    event.preventDefault();
                    const nextSibling = nextRow.cells[idx];
                    keyboardNavigation(nextSibling);
                }
            } else if (event.key === "ArrowLeft") {
                // left arrow
                event.preventDefault();
                const previousSibling = isRTL ? start.nextElementSibling : start.previousElementSibling;
                keyboardNavigation(previousSibling);
                event.stopPropagation();
            } else if (event.key === "ArrowRight") {
                // right arrow
                event.preventDefault();
                const nextsibling = isRTL ? start.previousElementSibling : start.nextElementSibling;
                keyboardNavigation(nextsibling);
                event.stopPropagation();
            }
        }
        else {
            start = document.activeElement;
        }

    };

    const cells = gridElement.querySelectorAll('[role="gridcell"]');
    cells.forEach((cell) => {
        cell.columnDefinition = {
            columnDataKey: "",
            cellInternalFocusQueue: true,
            cellFocusTargetCallback: (cell) => {
                return cell.children[0];
            }
        }
        cell.addEventListener(
            "keydown",
            (event) => {
                if (event.target.role !== "gridcell" && (event.key === "ArrowRight" || event.key === "ArrowLeft")) {
                    event.stopPropagation();
                }
            },
            { signal }
        );
    });

    document.body.addEventListener('click', bodyClickHandler, { signal });
    document.body.addEventListener('mousedown', bodyClickHandler, { signal }); // Otherwise it seems strange that it doesn't go away until you release the mouse button
    document.body.addEventListener('keydown', bodyKeyDownHandler, { signal });
    gridElement.addEventListener('keydown', keyDownHandler, { signal });

    return {
        stop: () => {
            controller.abort();

            const index = grids.findIndex(grid => grid.id === gridElement.id);
            if (index > -1) {
                const grid = grids[index];
                if (grid.resizeController) {
                    grid.resizeController.abort();
                }
                grids.splice(index, 1);
            }
        }
    };
}

export function checkColumnPopupPosition(gridElement, selector) {
    const colPopup = gridElement.querySelector(selector);
    if (colPopup) {
        const gridRect = gridElement.getBoundingClientRect();
        const popupRect = colPopup.getBoundingClientRect();
        const leftOverhang = Math.max(0, gridRect.left - popupRect.left);
        const rightOverhang = Math.max(0, popupRect.right - gridRect.right);
        if (leftOverhang || rightOverhang) {
            const applyOffset = leftOverhang && rightOverhang ? (leftOverhang - rightOverhang) / 2 : (leftOverhang - rightOverhang);
            colPopup.style.transform = `translateX(${applyOffset}px)`;
        }

        colPopup.style.visibility = 'visible';
        colPopup.scrollIntoViewIfNeeded();

        const autoFocusElem = colPopup.querySelector('[autofocus]');
        if (autoFocusElem) {
            autoFocusElem.focus();
        }
    }
}

export function enableColumnResizing(gridElement, resizeColumnOnAllRows = true, signal = null) {
    const columns = [];
    const headers = gridElement.querySelectorAll('.column-header.resizable');

    if (headers.length === 0) {
        return;
    }

    const id = gridElement.id;
    let grid = grids.find(g => g.id === id);

    if (grid?.resizeController) {
        grid.resizeController.abort();
    }

    const localController = signal ? null : new AbortController();
    const effectiveSignal = signal ?? localController.signal;

    const isGrid = gridElement.classList.contains('grid')

    let tableHeight = gridElement.offsetHeight;
    // rows have not been loaded yet, so we need to calculate the height
    if (tableHeight < 70) {
        // by getting the aria rowcount attribute
        const rowCount = gridElement.getAttribute('aria-rowcount');
        if (rowCount) {
            const rowHeight = gridElement.querySelector('thead tr th').offsetHeight;
            // and multiply by the itemsize (== height of the header cells)
            tableHeight = rowCount * rowHeight;
        }
    }

    // Determine the height based on the resizeColumnOnAllRows parameter
    let resizeHandleHeight = tableHeight;
    if (!resizeColumnOnAllRows) {
        // Only use the header height when resizeColumnOnAllRows is false
        // Use the first header's height if available
        resizeHandleHeight = headers.length > 0 ? (headers[0].offsetHeight - 14) : 32; // fallback to 32px if no headers
    }

    headers.forEach((header) => {
        columns.push({
            header,
            size: `${header.clientWidth}px`,
        });

        // remove any previously created divs
        const resizedivs = header.querySelectorAll(".actual-resize-handle");
        resizedivs.forEach(div => div.remove());

        // Get the top of the first resize-handle
        const resizeTop = header.querySelector('.resize-handle').offsetTop;

        // add a new resize div
        const div = createDiv(resizeHandleHeight, resizeTop);
        header.appendChild(div);
        setListeners(div, effectiveSignal);
    });

    let initialWidths;
    if (gridElement.style.gridTemplateColumns) {
        initialWidths = gridElement.style.gridTemplateColumns;
    } else {
        initialWidths = columns.map(({ size }) => size).join(' ');

        if (isGrid) {
            gridElement.style.gridTemplateColumns = initialWidths;
        }
    }

    if (!grid) {
        grids.push({
            id,
            columns,
            initialWidths,
            resizeController: signal ? undefined : localController,
        });
    } else {
        const columnsChanged = grid.columns.length !== columns.length;
        grid.columns = columns;
        if (columnsChanged) {
            grid.initialWidths = initialWidths;
        }
        grid.resizeController = signal ? undefined : localController;
    }

    function setListeners(div, signal) {
        let pageX, curCol, curColWidth;

        const moveHandler = (e) =>
            requestAnimationFrame(() => {
                gridElement.style.tableLayout = 'fixed';

                if (curCol) {
                    const isRTL = getComputedStyle(gridElement).direction === 'rtl';
                    const diffX = isRTL ? pageX - e.pageX : e.pageX - pageX;
                    const column = columns.find(({ header }) => header === curCol);

                    column.size = parseInt(Math.max(parseInt(column.header.style.minWidth), curColWidth + diffX), 10) + 'px';

                    columns.forEach((col) => {
                        if (col.size.startsWith('minmax')) {
                            col.size = parseInt(col.header.clientWidth, 10) + 'px';
                        }
                    });

                    if (isGrid) {
                        gridElement.style.gridTemplateColumns = columns
                            .map(({ size }) => size)
                            .join(' ');
                    }
                    else {
                        curCol.style.width = column.size;
                    }
                }
            });

        const upHandler = function () {
            gridElement.removeEventListener('pointermove', moveHandler);
            gridElement.removeEventListener('pointerup', upHandler);

            curCol = undefined;
            curColWidth = undefined;
            pageX = undefined;
        };

        div.addEventListener('pointerdown', function (e) {
            curCol = e.target.parentElement;
            pageX = e.pageX;

            const padding = paddingDiff(curCol);

            curColWidth = curCol.offsetWidth - padding;

            gridElement.addEventListener('pointermove', moveHandler, { signal });
            gridElement.addEventListener('pointerup', upHandler, { signal });
        }, { signal });

        div.addEventListener('pointerover', function (e) {
            e.target.style.borderInlineEnd = 'var(--fluent-data-grid-resize-handle-width) solid var(--fluent-data-grid-resize-handle-color)';
            e.target.previousElementSibling.style.visibility = 'hidden';
        }, { signal });

        div.addEventListener('pointerup', removeBorder, { signal });
        div.addEventListener('pointercancel', removeBorder, { signal });
        div.addEventListener('pointerleave', removeBorder, { signal });
    }

    function createDiv(height, top) {
        const div = document.createElement('div');
        div.className = "actual-resize-handle";
        div.style.top = top + 'px';
        div.style.position = 'absolute';
        div.style.cursor = 'col-resize';
        div.style.userSelect = 'none';
        div.style.height = (height - 4) + 'px';
        div.style.width = '6px';
        div.style.opacity = 'var(--fluent-data-grid-header-opacity)'
        div.style.insetInlineEnd = '0';

        return div;
    }

    function paddingDiff(col) {
        if (getStyleVal(col, 'box-sizing') === 'border-box') {
            return 0;
        }

        const padLeft = getStyleVal(col, 'padding-left');
        const padRight = getStyleVal(col, 'padding-right');
        return parseInt(padLeft) + parseInt(padRight);
    }

    function getStyleVal(elm, css) {
        return window.getComputedStyle(elm, null).getPropertyValue(css);
    }

    function removeBorder(e) {
        e.target.style.borderInlineEnd = '';
        e.target.previousElementSibling.style.visibility = 'visible';
    }
}



export function resetColumnWidths(gridElement) {
    const isGrid = gridElement.classList.contains('grid');
    const grid = grids.find(({ id }) => id === gridElement.id);
    if (!grid) {
        return;
    }

    if (isGrid) {
        gridElement.style.gridTemplateColumns = grid.initialWidths;

        // Force browser to recalculate so we can get accurate computed widths
        const resolvedWidths = window.getComputedStyle(gridElement).gridTemplateColumns.split(' ');

        grid.columns.forEach((column, index) => {
            column.size = resolvedWidths[index];
        });
    } else {
        const columnsWidths = grid.initialWidths.split(' ');
        grid.columns.forEach((column, index) => {
            column.size = columnsWidths[index];
            column.header.style.width = column.size;
        });
    }

    gridElement.dispatchEvent(
        new CustomEvent('closecolumnresize', { bubbles: true })
    );
    gridElement.focus();
}

export function resizeColumnDiscrete(gridElement, column, change) {
    const isGrid = gridElement.classList.contains('grid');
    const columns = [];
    let headerBeingResized;

    if (!column) {
        const targetElement = document.activeElement.parentElement.parentElement.parentElement.parentElement;
        if (!(targetElement.classList.contains("column-header") && targetElement.classList.contains("resizable"))) {
            return;
        }
        headerBeingResized = targetElement;
    }
    else {
        headerBeingResized = gridElement.querySelector('.column-header[col-index="' + column + '"]');
    }


    grids.find(({ id }) => id === gridElement.id).columns.forEach(column => {
        if (column.header === headerBeingResized) {
            const width = headerBeingResized.offsetWidth + change; //.getBoundingClientRect().width + change;

            if (change < 0) {
                column.size = Math.max(parseInt(column.header.style.minWidth), width) + 'px';
            }
            else {
                column.size = width + 'px';
            }
            column.header.style.width = column.size;
        }
        if (isGrid) {
            // for grid we need to recalculate all columns that are minmax
            if (column.size.startsWith('minmax')) {
                column.size = parseInt(column.header.clientWidth, 10) + 'px';
            }
            columns.push(column.size);
        }
    });

    if (isGrid) {
        gridElement.style.gridTemplateColumns = columns.join(' ');
    }
}

export function resizeColumnExact(gridElement, column, width) {
    const isGrid = gridElement.classList.contains('grid');
    const columns = [];
    let headerBeingResized = gridElement.querySelector('.column-header[col-index="' + column + '"]');

    if (!headerBeingResized) {
        return;
    }

    grids.find(({ id }) => id === gridElement.id).columns.forEach(column => {
        if (column.header === headerBeingResized) {
            column.size = Math.max(parseInt(column.header.style.minWidth), width) + 'px';
            column.header.style.width = column.size;
        }
        if (isGrid) {
            // for grid we need to recalculate all columns that are minmax
            if (column.size.startsWith('minmax')) {
                column.size = parseInt(column.header.clientWidth, 10) + 'px';
            }
            column.header.style.width = column.size;
            columns.push(column.size);
        }
    });

    if (isGrid) {
        gridElement.style.gridTemplateColumns = columns.join(' ');
    }

    gridElement.dispatchEvent(new CustomEvent('closecolumnresize', { bubbles: true }));
    gridElement.focus();
}

export function autoFitGridColumns(gridElement, columnCount) {
    let gridTemplateColumns = '';

    for (var i = 0; i < columnCount; i++) {
        const columnWidths = Array
            .from(gridElement.querySelectorAll(`[col-index="${i + 1}"]`))
            .flatMap((x) => x.offsetWidth);

        const maxColumnWidth = Math.max(...columnWidths);

        gridTemplateColumns += ` ${maxColumnWidth}px`;
    }

    gridElement.style.gridTemplateColumns = gridTemplateColumns;
    gridElement.classList.remove("auto-fit");

    const grid = grids.find(grid => grid.id === gridElement.id);
    if (grid) {
        grid.initialWidths = gridTemplateColumns;
    }
}

function calculateVisibleRows(gridElement, rowHeight) {
    if (rowHeight <= 0) {
        return 0;
    }

    const gridContainer = gridElement.parentElement;

    if (!gridContainer) {
        return 0;
    }

    const availableHeight = gridContainer?.clientHeight || window.visualViewport?.height || window.innerHeight;

    const visibleRows = Math.max(Math.floor(availableHeight / rowHeight), 1);
    return visibleRows;
}

export function dynamicItemsPerPage(gridElement, dotNetObject, rowSize) {
    const observer = new ResizeObserver(() => {
        const visibleRows = calculateVisibleRows(gridElement, rowSize)
        dotNetObject.invokeMethodAsync('UpdateItemsPerPageAsync', visibleRows)
            .catch(err => console.error("Error invoking Blazor method:", err));
    });

    const targetElement = gridElement.parentElement;
    if (targetElement) {
        observer.observe(targetElement);
    }
}
