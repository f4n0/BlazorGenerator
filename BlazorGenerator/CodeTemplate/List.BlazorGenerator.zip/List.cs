﻿using BlazorGenerator.Attributes;
using BlazorGenerator.Pages;
using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
  //[Route("/$safeitemname$")]
  //[AddToMenu(Title = "The Title", Route = "/$safeitemname$", Icon = Blazorise.IconName.$safeitemname$)]
  //[BasicActions(true, true, true)]
  public partial class $safeitemname$ : ListPage<$safeitemname$>
  {
    protected override async Task OnInitializedAsync()
    {
      //set here the VisibleFields lists 
    }
  }
}
